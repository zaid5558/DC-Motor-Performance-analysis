R  = 240;          % ohm
V  = 240;          % Volt
L  = 12*(10^(-3)); % Henry
J  = 1;            % km/m^3
B  = 0;            % 
T  = 29.2;         % rated Torgue
K  = 1;
